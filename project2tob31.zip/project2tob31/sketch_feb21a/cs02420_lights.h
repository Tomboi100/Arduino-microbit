/*
 * Author: Helen Miles (hem23@aber.ac.uk)
 * Functions to set up and use lights with the Arduino UNO + AU Morse Shield
*/
#define LED_RED 5
#define LED_ORANGE 6
#define LED_YELLOW 9
#define LED_GREEN 10
#define LED_BLUE 11

#define POTENTIOMETER A0
#define BUTTON 3
bool buttonPressed = false;

void setupLightPins() {
  // **********************************************************************
  // tell the program where to find all of your LEDs on the Arduino board
  // **********************************************************************
  const int len = 5;
  int leds[len] = {LED_RED, LED_ORANGE, LED_YELLOW, LED_GREEN, LED_BLUE};
  for(int led = 0; led < len; led++) {
    pinMode(leds[led], OUTPUT);
  }
}

void setupButton(){
  // **********************************************************************
  // tell the program where to find the button on the Arduino board
  // **********************************************************************
  pinMode(BUTTON, INPUT);
}

void led(int LED, int flashLength){
  // **********************************************************************
  // turn on an LED for the number of milliseconds given
  // **********************************************************************
  digitalWrite(LED, HIGH);  // turn LED on
  delay(flashLength);       // wait flashLength milliseconds
  digitalWrite(LED, LOW);   // turn LED off
}

void ledAnalog(int LED, int flashLength, int power){
  // **********************************************************************
  // turn on an LED for the number of milliseconds given
  // **********************************************************************
  analogWrite(LED, power);  // turn LED up to amount in power
  delay(flashLength);       // wait flashLength milliseconds
  analogWrite(LED, 0);      // turn LED down to zero power
}

void checkButton(){
  // **********************************************************************
  // check whether the button has been pressed or not
  // **********************************************************************
  buttonPressed = digitalRead(BUTTON);
}
