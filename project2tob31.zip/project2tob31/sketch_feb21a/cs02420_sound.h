/*
 * Author: Helen Miles (hem23@aber.ac.uk)
 * Functions to set up and use sound with the Arduino UNO + AU Morse Shield
*/
#include "pitches.h"
#define AUDIO_PIN A2

void setupSoundPin() {
  // **********************************************************************
  // tell the program where to find the headphone jack on the Arduino board
  // **********************************************************************
  pinMode(AUDIO_PIN, OUTPUT);
}

void beep(int pitch, int noteLength){
  // **********************************************************************
  // play a tone from the jack at the given pitch and for the given length
  // **********************************************************************
  int noteDuration = 1000 / noteLength;
  tone(AUDIO_PIN, pitch);
  delay(noteDuration);
  noTone(AUDIO_PIN);
}

void lightNote(int LED, int pitch, int noteLength){
  // **********************************************************************
  // play a tone from the jack at the given pitch and for the given length
  // while flashing an LED for the same amount of time
  // takes note lengths as 4 = quarter note, 8 = eighth note, etc.
  // **********************************************************************
  int noteDuration = 1000 / noteLength;
  tone(AUDIO_PIN, pitch);
  led(LED, noteDuration);
  noTone(AUDIO_PIN);
}
